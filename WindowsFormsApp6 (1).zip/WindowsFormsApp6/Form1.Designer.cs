﻿namespace WindowsFormsApp6
{
    partial class frmCourseWork3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCartPrice = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.lblEnterSalesIncome = new System.Windows.Forms.Label();
            this.lblBonusIncome = new System.Windows.Forms.Label();
            this.lblBonusLevel = new System.Windows.Forms.Label();
            this.txtCartPrice = new System.Windows.Forms.TextBox();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.txtEnterSalesIncome = new System.Windows.Forms.TextBox();
            this.txtBonusIncome = new System.Windows.Forms.TextBox();
            this.txtBonusLevel = new System.Windows.Forms.TextBox();
            this.bntSubmit = new System.Windows.Forms.Button();
            this.bntSubmit2 = new System.Windows.Forms.Button();
            this.bntClose = new System.Windows.Forms.Button();
            this.bntClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCartPrice
            // 
            this.lblCartPrice.AutoSize = true;
            this.lblCartPrice.Location = new System.Drawing.Point(119, 78);
            this.lblCartPrice.Name = "lblCartPrice";
            this.lblCartPrice.Size = new System.Drawing.Size(56, 13);
            this.lblCartPrice.TabIndex = 0;
            this.lblCartPrice.Text = "Cart Price:";
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.AutoSize = true;
            this.lblTotalPrice.Location = new System.Drawing.Point(119, 121);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(61, 13);
            this.lblTotalPrice.TabIndex = 1;
            this.lblTotalPrice.Text = "Total Price:";
            // 
            // lblEnterSalesIncome
            // 
            this.lblEnterSalesIncome.AutoSize = true;
            this.lblEnterSalesIncome.Location = new System.Drawing.Point(119, 215);
            this.lblEnterSalesIncome.Name = "lblEnterSalesIncome";
            this.lblEnterSalesIncome.Size = new System.Drawing.Size(102, 13);
            this.lblEnterSalesIncome.TabIndex = 2;
            this.lblEnterSalesIncome.Text = "Enter Sales Income:";
            // 
            // lblBonusIncome
            // 
            this.lblBonusIncome.AutoSize = true;
            this.lblBonusIncome.Location = new System.Drawing.Point(119, 262);
            this.lblBonusIncome.Name = "lblBonusIncome";
            this.lblBonusIncome.Size = new System.Drawing.Size(78, 13);
            this.lblBonusIncome.TabIndex = 3;
            this.lblBonusIncome.Text = "Bonus Income:";
            // 
            // lblBonusLevel
            // 
            this.lblBonusLevel.AutoSize = true;
            this.lblBonusLevel.Location = new System.Drawing.Point(119, 319);
            this.lblBonusLevel.Name = "lblBonusLevel";
            this.lblBonusLevel.Size = new System.Drawing.Size(69, 13);
            this.lblBonusLevel.TabIndex = 4;
            this.lblBonusLevel.Text = "Bonus Level:";
            // 
            // txtCartPrice
            // 
            this.txtCartPrice.Location = new System.Drawing.Point(315, 78);
            this.txtCartPrice.Name = "txtCartPrice";
            this.txtCartPrice.Size = new System.Drawing.Size(142, 20);
            this.txtCartPrice.TabIndex = 5;
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.Location = new System.Drawing.Point(357, 121);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.Size = new System.Drawing.Size(100, 20);
            this.txtTotalPrice.TabIndex = 6;
            // 
            // txtEnterSalesIncome
            // 
            this.txtEnterSalesIncome.Location = new System.Drawing.Point(357, 212);
            this.txtEnterSalesIncome.Name = "txtEnterSalesIncome";
            this.txtEnterSalesIncome.Size = new System.Drawing.Size(100, 20);
            this.txtEnterSalesIncome.TabIndex = 7;
            // 
            // txtBonusIncome
            // 
            this.txtBonusIncome.Location = new System.Drawing.Point(357, 262);
            this.txtBonusIncome.Name = "txtBonusIncome";
            this.txtBonusIncome.Size = new System.Drawing.Size(100, 20);
            this.txtBonusIncome.TabIndex = 8;
            // 
            // txtBonusLevel
            // 
            this.txtBonusLevel.Location = new System.Drawing.Point(357, 316);
            this.txtBonusLevel.Name = "txtBonusLevel";
            this.txtBonusLevel.Size = new System.Drawing.Size(100, 20);
            this.txtBonusLevel.TabIndex = 9;
            // 
            // bntSubmit
            // 
            this.bntSubmit.Location = new System.Drawing.Point(688, 124);
            this.bntSubmit.Name = "bntSubmit";
            this.bntSubmit.Size = new System.Drawing.Size(75, 23);
            this.bntSubmit.TabIndex = 10;
            this.bntSubmit.Text = "&Submit";
            this.bntSubmit.UseVisualStyleBackColor = true;
            this.bntSubmit.Click += new System.EventHandler(this.bntSubmit_Click);
            // 
            // bntSubmit2
            // 
            this.bntSubmit2.Location = new System.Drawing.Point(688, 215);
            this.bntSubmit2.Name = "bntSubmit2";
            this.bntSubmit2.Size = new System.Drawing.Size(75, 23);
            this.bntSubmit2.TabIndex = 11;
            this.bntSubmit2.Text = "&Submit";
            this.bntSubmit2.UseVisualStyleBackColor = true;
            this.bntSubmit2.Click += new System.EventHandler(this.bntSubmit2_Click);
            // 
            // bntClose
            // 
            this.bntClose.Location = new System.Drawing.Point(592, 388);
            this.bntClose.Name = "bntClose";
            this.bntClose.Size = new System.Drawing.Size(75, 23);
            this.bntClose.TabIndex = 12;
            this.bntClose.Text = "&Close";
            this.bntClose.UseVisualStyleBackColor = true;
            this.bntClose.Click += new System.EventHandler(this.bntClose_Click);
            // 
            // bntClear
            // 
            this.bntClear.Location = new System.Drawing.Point(280, 387);
            this.bntClear.Name = "bntClear";
            this.bntClear.Size = new System.Drawing.Size(75, 23);
            this.bntClear.TabIndex = 13;
            this.bntClear.Text = "&Clear";
            this.bntClear.UseVisualStyleBackColor = true;
            this.bntClear.Click += new System.EventHandler(this.bntClear_Click);
            // 
            // frmCourseWork3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntClear);
            this.Controls.Add(this.bntClose);
            this.Controls.Add(this.bntSubmit2);
            this.Controls.Add(this.bntSubmit);
            this.Controls.Add(this.txtBonusLevel);
            this.Controls.Add(this.txtBonusIncome);
            this.Controls.Add(this.txtEnterSalesIncome);
            this.Controls.Add(this.txtTotalPrice);
            this.Controls.Add(this.txtCartPrice);
            this.Controls.Add(this.lblBonusLevel);
            this.Controls.Add(this.lblBonusIncome);
            this.Controls.Add(this.lblEnterSalesIncome);
            this.Controls.Add(this.lblTotalPrice);
            this.Controls.Add(this.lblCartPrice);
            this.Name = "frmCourseWork3";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCartPrice;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label lblEnterSalesIncome;
        private System.Windows.Forms.Label lblBonusIncome;
        private System.Windows.Forms.Label lblBonusLevel;
        private System.Windows.Forms.TextBox txtCartPrice;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.TextBox txtEnterSalesIncome;
        private System.Windows.Forms.TextBox txtBonusIncome;
        private System.Windows.Forms.TextBox txtBonusLevel;
        private System.Windows.Forms.Button bntSubmit;
        private System.Windows.Forms.Button bntSubmit2;
        private System.Windows.Forms.Button bntClose;
        private System.Windows.Forms.Button bntClear;
    }
}

