﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class frmCourseWork3 : Form
    {
        public frmCourseWork3()
        {
            InitializeComponent();
        }

        private void bntSubmit_Click(object sender, EventArgs e)
        {
            double CartPrice;
            double TotalPrice;

            CartPrice = double.Parse(txtCartPrice.Text);

            if (CartPrice <= 50)
            {
                TotalPrice = CartPrice + (CartPrice * .05);

            }
            else if (CartPrice <= 100)
            {
                TotalPrice = CartPrice + (CartPrice * .03);
            }
            else
            {
                TotalPrice = CartPrice;
            }
            txtTotalPrice.Text = TotalPrice.ToString("c");
        }

        private void bntSubmit2_Click(object sender, EventArgs e)
        {
            double SalesIncome;
            double BonusIncome;
            string BonusLevel;

            SalesIncome = double.Parse(txtEnterSalesIncome.Text);

            if (SalesIncome <= 50000)
            {
                BonusIncome = SalesIncome * .10;
                BonusLevel = "Silver";

            }
            else if (SalesIncome <= 250000)
            {
                BonusIncome = 7500 + SalesIncome * .15;
                BonusLevel = "Gold";
            }
            else
            {
                BonusIncome = 12500 + SalesIncome * .20;
                BonusLevel = "Platinum";
            }
            txtBonusIncome.Text = BonusIncome.ToString("c");
            txtBonusLevel.Text = BonusLevel;
        }

        private void bntClear_Click(object sender, EventArgs e)
        {
            txtBonusIncome.Text = "";
            txtBonusLevel.Text = "";
            txtCartPrice.Text = "";
            txtEnterSalesIncome.Text = "";
            txtTotalPrice.Text = "";
        }

        private void bntClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
