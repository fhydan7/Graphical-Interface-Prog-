﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FahadProject4
{
    class Calculation
    {
        public double InputNumber = 0;
        public double SeriesSum = 0;
        public double ProductSum = 0;
        public decimal DivisionSum = 0;
        public double LimitSum = 0;
        public double OddSum = 0;
        public double ProductOdd = 0;

        public Calculation(double inputNumber)
        {
            InputNumber = inputNumber;
            SeriesSum = MethodSeriesSum();
            ProductSum = MethodProductSum();
            DivisionSum = MethodDivisionSum();
            LimitSum = MethodLimitSum();
            OddSum = MethodOddSum();
            ProductOdd = MethodProductOdd();
        }

        private double MethodSeriesSum()
        {
            double counter = 0;
            double seriesSum = 0;
            while (counter <= InputNumber)
            {
                seriesSum = counter + seriesSum;
                counter++;
            }
            return seriesSum;
            }

        public double MethodProductSum()
        {
            double counter = 1;
            double productSum = 1;
            while (counter <= InputNumber)
            {
                productSum = counter * productSum;
                counter++;
            }
            return productSum;
        }

        public decimal MethodDivisionSum()
        {
            decimal counter = 2;
            decimal divisionSum = 1;
            while (counter <= Convert.ToDecimal(InputNumber))
            {
                divisionSum = divisionSum / counter;
                counter++;
            }
            return divisionSum;
        }

        public double MethodLimitSum()
        {
            double counter = 1;
            double x = 1;
            double limitSum = 0;
            while (counter <= InputNumber)
            {
                limitSum += x/counter;
                counter++;
            }
            return limitSum;
        }

        public double MethodOddSum()
        {
            int sum = 0;
            for (int i = 1; i <= InputNumber; i+=2)
            {
                int temp = 0;
                int k = 1;
                for (int j = 1; j <= i; j+=2)
                {
                    temp += k;
                    k += 2;
                }
                sum += temp;
            }
            return sum;
        }

        public double MethodProductOdd()
        {
            
            double product = 1;
            for (int i = 1; i <= InputNumber; i+=2)
            {
                double sum = 0;
                double k = 1;
                for (int j = 1; j <= i; j+=2)
                {
                    sum += k;
                    k += 2;
                }
                product = product * sum;
            }
            return product;
        }
    }
}
