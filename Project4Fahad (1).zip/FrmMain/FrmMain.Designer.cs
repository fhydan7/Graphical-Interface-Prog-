﻿namespace FrmMain
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInputNumber = new System.Windows.Forms.TextBox();
            this.lblSeriesSum = new System.Windows.Forms.Label();
            this.lblProductSum = new System.Windows.Forms.Label();
            this.lblDivisionSum = new System.Windows.Forms.Label();
            this.lblLimitSum = new System.Windows.Forms.Label();
            this.lblOddSum = new System.Windows.Forms.Label();
            this.lblOddProduct = new System.Windows.Forms.Label();
            this.txtLimitSum = new System.Windows.Forms.TextBox();
            this.txtOddSum = new System.Windows.Forms.TextBox();
            this.txtOddProduct = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtDivisionSum = new System.Windows.Forms.TextBox();
            this.txtSeriesSum = new System.Windows.Forms.TextBox();
            this.txtProductSum = new System.Windows.Forms.TextBox();
            this.grpInputNumber = new System.Windows.Forms.GroupBox();
            this.grpInputNumber.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtInputNumber
            // 
            this.txtInputNumber.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInputNumber.Location = new System.Drawing.Point(133, 19);
            this.txtInputNumber.Name = "txtInputNumber";
            this.txtInputNumber.Size = new System.Drawing.Size(128, 30);
            this.txtInputNumber.TabIndex = 1;
            // 
            // lblSeriesSum
            // 
            this.lblSeriesSum.BackColor = System.Drawing.Color.White;
            this.lblSeriesSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSeriesSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeriesSum.Location = new System.Drawing.Point(42, 100);
            this.lblSeriesSum.Name = "lblSeriesSum";
            this.lblSeriesSum.Size = new System.Drawing.Size(147, 30);
            this.lblSeriesSum.TabIndex = 2;
            this.lblSeriesSum.Text = "Sum of Series";
            // 
            // lblProductSum
            // 
            this.lblProductSum.BackColor = System.Drawing.Color.White;
            this.lblProductSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductSum.Location = new System.Drawing.Point(42, 178);
            this.lblProductSum.Name = "lblProductSum";
            this.lblProductSum.Size = new System.Drawing.Size(163, 30);
            this.lblProductSum.TabIndex = 3;
            this.lblProductSum.Text = "Product of Sum";
            // 
            // lblDivisionSum
            // 
            this.lblDivisionSum.BackColor = System.Drawing.Color.White;
            this.lblDivisionSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDivisionSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDivisionSum.Location = new System.Drawing.Point(42, 251);
            this.lblDivisionSum.Name = "lblDivisionSum";
            this.lblDivisionSum.Size = new System.Drawing.Size(164, 30);
            this.lblDivisionSum.TabIndex = 4;
            this.lblDivisionSum.Text = "Division of Sum";
            // 
            // lblLimitSum
            // 
            this.lblLimitSum.BackColor = System.Drawing.Color.White;
            this.lblLimitSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLimitSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLimitSum.Location = new System.Drawing.Point(476, 103);
            this.lblLimitSum.Name = "lblLimitSum";
            this.lblLimitSum.Size = new System.Drawing.Size(142, 30);
            this.lblLimitSum.TabIndex = 8;
            this.lblLimitSum.Text = "Sum of Limit";
            // 
            // lblOddSum
            // 
            this.lblOddSum.BackColor = System.Drawing.Color.White;
            this.lblOddSum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOddSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOddSum.Location = new System.Drawing.Point(476, 178);
            this.lblOddSum.Name = "lblOddSum";
            this.lblOddSum.Size = new System.Drawing.Size(142, 30);
            this.lblOddSum.TabIndex = 9;
            this.lblOddSum.Text = "Sum of Odd";
            // 
            // lblOddProduct
            // 
            this.lblOddProduct.BackColor = System.Drawing.Color.White;
            this.lblOddProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOddProduct.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOddProduct.Location = new System.Drawing.Point(476, 273);
            this.lblOddProduct.Name = "lblOddProduct";
            this.lblOddProduct.Size = new System.Drawing.Size(142, 22);
            this.lblOddProduct.TabIndex = 10;
            this.lblOddProduct.Text = "Product Of Odd";
            // 
            // txtLimitSum
            // 
            this.txtLimitSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLimitSum.Location = new System.Drawing.Point(641, 103);
            this.txtLimitSum.Name = "txtLimitSum";
            this.txtLimitSum.Size = new System.Drawing.Size(136, 29);
            this.txtLimitSum.TabIndex = 11;
            // 
            // txtOddSum
            // 
            this.txtOddSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOddSum.Location = new System.Drawing.Point(641, 178);
            this.txtOddSum.Name = "txtOddSum";
            this.txtOddSum.Size = new System.Drawing.Size(136, 29);
            this.txtOddSum.TabIndex = 12;
            // 
            // txtOddProduct
            // 
            this.txtOddProduct.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOddProduct.Location = new System.Drawing.Point(641, 265);
            this.txtOddProduct.Name = "txtOddProduct";
            this.txtOddProduct.Size = new System.Drawing.Size(136, 29);
            this.txtOddProduct.TabIndex = 13;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(329, 364);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(152, 35);
            this.btnCalculate.TabIndex = 14;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(90, 425);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(116, 37);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(641, 425);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(119, 37);
            this.btnClose.TabIndex = 16;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtDivisionSum
            // 
            this.txtDivisionSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDivisionSum.Location = new System.Drawing.Point(220, 251);
            this.txtDivisionSum.Name = "txtDivisionSum";
            this.txtDivisionSum.Size = new System.Drawing.Size(142, 29);
            this.txtDivisionSum.TabIndex = 23;
            // 
            // txtSeriesSum
            // 
            this.txtSeriesSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeriesSum.Location = new System.Drawing.Point(220, 100);
            this.txtSeriesSum.Name = "txtSeriesSum";
            this.txtSeriesSum.Size = new System.Drawing.Size(142, 29);
            this.txtSeriesSum.TabIndex = 21;
            // 
            // txtProductSum
            // 
            this.txtProductSum.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductSum.Location = new System.Drawing.Point(220, 178);
            this.txtProductSum.Name = "txtProductSum";
            this.txtProductSum.Size = new System.Drawing.Size(142, 29);
            this.txtProductSum.TabIndex = 22;
            // 
            // grpInputNumber
            // 
            this.grpInputNumber.Controls.Add(this.txtInputNumber);
            this.grpInputNumber.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpInputNumber.Location = new System.Drawing.Point(220, 13);
            this.grpInputNumber.Name = "grpInputNumber";
            this.grpInputNumber.Size = new System.Drawing.Size(364, 81);
            this.grpInputNumber.TabIndex = 24;
            this.grpInputNumber.TabStop = false;
            this.grpInputNumber.Text = "Input Number:";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 529);
            this.Controls.Add(this.grpInputNumber);
            this.Controls.Add(this.txtDivisionSum);
            this.Controls.Add(this.txtSeriesSum);
            this.Controls.Add(this.txtProductSum);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtOddProduct);
            this.Controls.Add(this.txtOddSum);
            this.Controls.Add(this.txtLimitSum);
            this.Controls.Add(this.lblOddProduct);
            this.Controls.Add(this.lblOddSum);
            this.Controls.Add(this.lblLimitSum);
            this.Controls.Add(this.lblDivisionSum);
            this.Controls.Add(this.lblProductSum);
            this.Controls.Add(this.lblSeriesSum);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.grpInputNumber.ResumeLayout(false);
            this.grpInputNumber.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtInputNumber;
        private System.Windows.Forms.Label lblSeriesSum;
        private System.Windows.Forms.Label lblProductSum;
        private System.Windows.Forms.Label lblDivisionSum;
        private System.Windows.Forms.Label lblLimitSum;
        private System.Windows.Forms.Label lblOddSum;
        private System.Windows.Forms.Label lblOddProduct;
        private System.Windows.Forms.TextBox txtLimitSum;
        private System.Windows.Forms.TextBox txtOddSum;
        private System.Windows.Forms.TextBox txtOddProduct;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtDivisionSum;
        private System.Windows.Forms.TextBox txtSeriesSum;
        private System.Windows.Forms.TextBox txtProductSum;
        private System.Windows.Forms.GroupBox grpInputNumber;
    }
}

