﻿using System;
using FahadProject4;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmMain
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent(); 
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            double InputNumber = double.Parse(txtInputNumber.Text);

            Calculation aCalculation;
            aCalculation = new Calculation(InputNumber);
            double SeriesSum = aCalculation.SeriesSum;
            double ProductSum = aCalculation.ProductSum;
            decimal DivisionSum = aCalculation.DivisionSum;
            double LimitSum = aCalculation.LimitSum;
            double OddSum = aCalculation.OddSum;
            double ProductOdd = aCalculation.ProductOdd;
            txtSeriesSum.Text = SeriesSum.ToString();
            txtProductSum.Text = ProductSum.ToString();
            txtDivisionSum.Text = DivisionSum.ToString("n8");
            txtLimitSum.Text = LimitSum.ToString("n2");
            txtOddSum.Text = OddSum.ToString();
            txtOddProduct.Text = ProductOdd.ToString();


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOddProduct.Text = null;
            txtDivisionSum.Text = null;
            txtLimitSum.Text = null;
            txtOddSum.Text = null;
            txtProductSum.Text = null;
            txtSeriesSum.Text = null;
            txtInputNumber.Text = null;
            txtInputNumber.Focus();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
