﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lblChickenSandwich = new System.Windows.Forms.Label();
            this.lblWaffleFries = new System.Windows.Forms.Label();
            this.lblChickenNuggets = new System.Windows.Forms.Label();
            this.lblChickenSalad = new System.Windows.Forms.Label();
            this.lblCola = new System.Windows.Forms.Label();
            this.lblDrPepper = new System.Windows.Forms.Label();
            this.lstListBox = new System.Windows.Forms.ListBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.grpNutritionTotals = new System.Windows.Forms.GroupBox();
            this.lblTotalFat = new System.Windows.Forms.Label();
            this.lblTotalProtein = new System.Windows.Forms.Label();
            this.lblTotalSodium = new System.Windows.Forms.Label();
            this.lblTotalCalories = new System.Windows.Forms.Label();
            this.lblFat = new System.Windows.Forms.Label();
            this.lblProtein = new System.Windows.Forms.Label();
            this.lblSodium = new System.Windows.Forms.Label();
            this.lblCalories = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.grpNutritionTotals.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(22, 286);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(209, 141);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 87);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(219, 145);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(237, 87);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(228, 145);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(242, 286);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(223, 141);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(471, 87);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(82, 145);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(471, 286);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(82, 141);
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // lblChickenSandwich
            // 
            this.lblChickenSandwich.AutoSize = true;
            this.lblChickenSandwich.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenSandwich.Location = new System.Drawing.Point(19, 59);
            this.lblChickenSandwich.Name = "lblChickenSandwich";
            this.lblChickenSandwich.Size = new System.Drawing.Size(166, 19);
            this.lblChickenSandwich.TabIndex = 6;
            this.lblChickenSandwich.Text = "Chicken Sandwich  $3.05";
            // 
            // lblWaffleFries
            // 
            this.lblWaffleFries.AutoSize = true;
            this.lblWaffleFries.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWaffleFries.Location = new System.Drawing.Point(19, 258);
            this.lblWaffleFries.Name = "lblWaffleFries";
            this.lblWaffleFries.Size = new System.Drawing.Size(122, 19);
            this.lblWaffleFries.TabIndex = 7;
            this.lblWaffleFries.Text = "Waffle Fries $1.85";
            this.lblWaffleFries.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblChickenNuggets
            // 
            this.lblChickenNuggets.AutoSize = true;
            this.lblChickenNuggets.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenNuggets.Location = new System.Drawing.Point(239, 59);
            this.lblChickenNuggets.Name = "lblChickenNuggets";
            this.lblChickenNuggets.Size = new System.Drawing.Size(153, 19);
            this.lblChickenNuggets.TabIndex = 8;
            this.lblChickenNuggets.Text = "Chicken Nuggets $4.45";
            // 
            // lblChickenSalad
            // 
            this.lblChickenSalad.AutoSize = true;
            this.lblChickenSalad.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenSalad.Location = new System.Drawing.Point(239, 258);
            this.lblChickenSalad.Name = "lblChickenSalad";
            this.lblChickenSalad.Size = new System.Drawing.Size(137, 19);
            this.lblChickenSalad.TabIndex = 9;
            this.lblChickenSalad.Text = "Chicken Salad $7.19";
            // 
            // lblCola
            // 
            this.lblCola.AutoSize = true;
            this.lblCola.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCola.Location = new System.Drawing.Point(468, 59);
            this.lblCola.Name = "lblCola";
            this.lblCola.Size = new System.Drawing.Size(78, 19);
            this.lblCola.TabIndex = 10;
            this.lblCola.Text = "Cola $2.75";
            // 
            // lblDrPepper
            // 
            this.lblDrPepper.AutoSize = true;
            this.lblDrPepper.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrPepper.Location = new System.Drawing.Point(468, 258);
            this.lblDrPepper.Name = "lblDrPepper";
            this.lblDrPepper.Size = new System.Drawing.Size(112, 19);
            this.lblDrPepper.TabIndex = 11;
            this.lblDrPepper.Text = "Dr.Pepper $2.75";
            this.lblDrPepper.Click += new System.EventHandler(this.label6_Click);
            // 
            // lstListBox
            // 
            this.lstListBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstListBox.FormattingEnabled = true;
            this.lstListBox.ItemHeight = 14;
            this.lstListBox.Location = new System.Drawing.Point(783, 102);
            this.lstListBox.Name = "lstListBox";
            this.lstListBox.Size = new System.Drawing.Size(203, 340);
            this.lstListBox.TabIndex = 12;
            this.lstListBox.SelectedIndexChanged += new System.EventHandler(this.lstListBox_SelectedIndexChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(780, 59);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(42, 19);
            this.lblTotal.TabIndex = 13;
            this.lblTotal.Text = "Total:";
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalPrice.Location = new System.Drawing.Point(834, 59);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(100, 23);
            this.lblTotalPrice.TabIndex = 14;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(783, 565);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 48);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(911, 565);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 48);
            this.BtnExit.TabIndex = 16;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // grpNutritionTotals
            // 
            this.grpNutritionTotals.BackColor = System.Drawing.Color.White;
            this.grpNutritionTotals.Controls.Add(this.lblTotalFat);
            this.grpNutritionTotals.Controls.Add(this.lblTotalProtein);
            this.grpNutritionTotals.Controls.Add(this.lblTotalSodium);
            this.grpNutritionTotals.Controls.Add(this.lblTotalCalories);
            this.grpNutritionTotals.Controls.Add(this.lblFat);
            this.grpNutritionTotals.Controls.Add(this.lblProtein);
            this.grpNutritionTotals.Controls.Add(this.lblSodium);
            this.grpNutritionTotals.Controls.Add(this.lblCalories);
            this.grpNutritionTotals.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpNutritionTotals.Location = new System.Drawing.Point(22, 472);
            this.grpNutritionTotals.Name = "grpNutritionTotals";
            this.grpNutritionTotals.Size = new System.Drawing.Size(548, 141);
            this.grpNutritionTotals.TabIndex = 17;
            this.grpNutritionTotals.TabStop = false;
            this.grpNutritionTotals.Text = "Nutrition Totals:";
            // 
            // lblTotalFat
            // 
            this.lblTotalFat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalFat.Location = new System.Drawing.Point(353, 80);
            this.lblTotalFat.Name = "lblTotalFat";
            this.lblTotalFat.Size = new System.Drawing.Size(100, 23);
            this.lblTotalFat.TabIndex = 7;
            // 
            // lblTotalProtein
            // 
            this.lblTotalProtein.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalProtein.Location = new System.Drawing.Point(236, 80);
            this.lblTotalProtein.Name = "lblTotalProtein";
            this.lblTotalProtein.Size = new System.Drawing.Size(100, 23);
            this.lblTotalProtein.TabIndex = 6;
            // 
            // lblTotalSodium
            // 
            this.lblTotalSodium.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalSodium.Location = new System.Drawing.Point(123, 80);
            this.lblTotalSodium.Name = "lblTotalSodium";
            this.lblTotalSodium.Size = new System.Drawing.Size(100, 23);
            this.lblTotalSodium.TabIndex = 5;
            // 
            // lblTotalCalories
            // 
            this.lblTotalCalories.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCalories.Location = new System.Drawing.Point(17, 80);
            this.lblTotalCalories.Name = "lblTotalCalories";
            this.lblTotalCalories.Size = new System.Drawing.Size(100, 23);
            this.lblTotalCalories.TabIndex = 4;
            // 
            // lblFat
            // 
            this.lblFat.AutoSize = true;
            this.lblFat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFat.Location = new System.Drawing.Point(390, 44);
            this.lblFat.Name = "lblFat";
            this.lblFat.Size = new System.Drawing.Size(29, 19);
            this.lblFat.TabIndex = 3;
            this.lblFat.Text = "Fat";
            // 
            // lblProtein
            // 
            this.lblProtein.AutoSize = true;
            this.lblProtein.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtein.Location = new System.Drawing.Point(257, 44);
            this.lblProtein.Name = "lblProtein";
            this.lblProtein.Size = new System.Drawing.Size(52, 19);
            this.lblProtein.TabIndex = 2;
            this.lblProtein.Text = "Protein";
            // 
            // lblSodium
            // 
            this.lblSodium.AutoSize = true;
            this.lblSodium.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSodium.Location = new System.Drawing.Point(134, 44);
            this.lblSodium.Name = "lblSodium";
            this.lblSodium.Size = new System.Drawing.Size(55, 19);
            this.lblSodium.TabIndex = 1;
            this.lblSodium.Text = "Sodium";
            this.lblSodium.Click += new System.EventHandler(this.lblSodium_Click);
            // 
            // lblCalories
            // 
            this.lblCalories.AutoSize = true;
            this.lblCalories.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalories.Location = new System.Drawing.Point(32, 44);
            this.lblCalories.Name = "lblCalories";
            this.lblCalories.Size = new System.Drawing.Size(59, 19);
            this.lblCalories.TabIndex = 0;
            this.lblCalories.Text = "Calories";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 690);
            this.Controls.Add(this.grpNutritionTotals);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblTotalPrice);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lstListBox);
            this.Controls.Add(this.lblDrPepper);
            this.Controls.Add(this.lblCola);
            this.Controls.Add(this.lblChickenSalad);
            this.Controls.Add(this.lblChickenNuggets);
            this.Controls.Add(this.lblWaffleFries);
            this.Controls.Add(this.lblChickenSandwich);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.grpNutritionTotals.ResumeLayout(false);
            this.grpNutritionTotals.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label lblChickenSandwich;
        private System.Windows.Forms.Label lblWaffleFries;
        private System.Windows.Forms.Label lblChickenNuggets;
        private System.Windows.Forms.Label lblChickenSalad;
        private System.Windows.Forms.Label lblCola;
        private System.Windows.Forms.Label lblDrPepper;
        private System.Windows.Forms.ListBox lstListBox;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.GroupBox grpNutritionTotals;
        private System.Windows.Forms.Label lblTotalFat;
        private System.Windows.Forms.Label lblTotalProtein;
        private System.Windows.Forms.Label lblTotalSodium;
        private System.Windows.Forms.Label lblTotalCalories;
        private System.Windows.Forms.Label lblFat;
        private System.Windows.Forms.Label lblProtein;
        private System.Windows.Forms.Label lblSodium;
        private System.Windows.Forms.Label lblCalories;
    }
}

