﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        double Total;
        int NutritionTotalsColaries;
        int NutritionTotalsSodium;
        int NutritionTotalsProtien;
        int NutritionTotalsFat;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            NutritionTotalsColaries = NutritionTotalsColaries + 440;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 3.05;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 1350;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 28;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 19;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add("Chicken Sandwich  $3.05");
            

        }

        private void lblSodium_Click(object sender, EventArgs e)
        {

        }

        private void lstListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            NutritionTotalsColaries = NutritionTotalsColaries + 260;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 4.45;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 980;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 28;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 12;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add("Chicken Nuggets $4.45");

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            NutritionTotalsColaries = NutritionTotalsColaries + 360;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 1.85;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 280;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 5;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 18;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add(" Waffle Fries $1.85");

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Total = 0;
            lblTotalPrice.Text = Total.ToString();
            NutritionTotalsColaries = 0;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            NutritionTotalsFat = 0;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            NutritionTotalsProtien = 0;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsSodium = 0;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            lstListBox.Items.Clear();


        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            NutritionTotalsColaries = NutritionTotalsColaries + 330;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 7.19;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 670;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 27;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 14;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add(" Chicken Salad $7.19");

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

            NutritionTotalsColaries = NutritionTotalsColaries + 260;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 2.75;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 90;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 0;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 0;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add(" Cola $2.75");

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

            NutritionTotalsColaries = NutritionTotalsColaries + 260;
            lblTotalCalories.Text = NutritionTotalsColaries.ToString();
            Total = Total + 2.75;
            lblTotalPrice.Text = Total.ToString("c");
            NutritionTotalsSodium = NutritionTotalsSodium + 90;
            lblTotalSodium.Text = NutritionTotalsSodium.ToString();
            NutritionTotalsProtien = NutritionTotalsProtien + 0;
            lblTotalProtein.Text = NutritionTotalsProtien.ToString();
            NutritionTotalsFat = NutritionTotalsFat + 0;
            lblTotalFat.Text = NutritionTotalsFat.ToString();
            lstListBox.Items.Add(" Dr.Pepper $2.75");

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
