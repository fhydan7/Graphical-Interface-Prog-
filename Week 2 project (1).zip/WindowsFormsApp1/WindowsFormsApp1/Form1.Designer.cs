﻿namespace WindowsFormsApp1
{
    partial class frmCourseWork2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.bntChange = new System.Windows.Forms.Button();
            this.lblRadio = new System.Windows.Forms.Label();
            this.lblPetSelect = new System.Windows.Forms.Label();
            this.radDog = new System.Windows.Forms.RadioButton();
            this.radCat = new System.Windows.Forms.RadioButton();
            this.radBird = new System.Windows.Forms.RadioButton();
            this.radSnake = new System.Windows.Forms.RadioButton();
            this.bntSelect = new System.Windows.Forms.Button();
            this.bntClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Yellow;
            this.lblWelcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWelcome.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Red;
            this.lblWelcome.Location = new System.Drawing.Point(414, 113);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(228, 39);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome all pets!";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblWelcome.Click += new System.EventHandler(this.label1_Click);
            // 
            // bntChange
            // 
            this.bntChange.Location = new System.Drawing.Point(796, 119);
            this.bntChange.Name = "bntChange";
            this.bntChange.Size = new System.Drawing.Size(75, 39);
            this.bntChange.TabIndex = 1;
            this.bntChange.Text = "Change";
            this.bntChange.UseVisualStyleBackColor = true;
            this.bntChange.Click += new System.EventHandler(this.bntChange_Click);
            // 
            // lblRadio
            // 
            this.lblRadio.AutoSize = true;
            this.lblRadio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRadio.Location = new System.Drawing.Point(414, 289);
            this.lblRadio.Name = "lblRadio";
            this.lblRadio.Size = new System.Drawing.Size(152, 18);
            this.lblRadio.TabIndex = 2;
            this.lblRadio.Text = "Select your favotite type of pet.";
            this.lblRadio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPetSelect
            // 
            this.lblPetSelect.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPetSelect.Location = new System.Drawing.Point(414, 532);
            this.lblPetSelect.Name = "lblPetSelect";
            this.lblPetSelect.Size = new System.Drawing.Size(348, 27);
            this.lblPetSelect.TabIndex = 3;
            this.lblPetSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radDog
            // 
            this.radDog.AutoSize = true;
            this.radDog.Location = new System.Drawing.Point(642, 239);
            this.radDog.Name = "radDog";
            this.radDog.Size = new System.Drawing.Size(46, 20);
            this.radDog.TabIndex = 4;
            this.radDog.TabStop = true;
            this.radDog.Text = "Dog";
            this.radDog.UseVisualStyleBackColor = true;
            // 
            // radCat
            // 
            this.radCat.AutoSize = true;
            this.radCat.Location = new System.Drawing.Point(642, 294);
            this.radCat.Name = "radCat";
            this.radCat.Size = new System.Drawing.Size(42, 20);
            this.radCat.TabIndex = 5;
            this.radCat.TabStop = true;
            this.radCat.Text = "Cat";
            this.radCat.UseVisualStyleBackColor = true;
            // 
            // radBird
            // 
            this.radBird.AutoSize = true;
            this.radBird.Location = new System.Drawing.Point(642, 350);
            this.radBird.Name = "radBird";
            this.radBird.Size = new System.Drawing.Size(45, 20);
            this.radBird.TabIndex = 6;
            this.radBird.TabStop = true;
            this.radBird.Text = "Bird";
            this.radBird.UseVisualStyleBackColor = true;
            this.radBird.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radSnake
            // 
            this.radSnake.AutoSize = true;
            this.radSnake.Location = new System.Drawing.Point(642, 402);
            this.radSnake.Name = "radSnake";
            this.radSnake.Size = new System.Drawing.Size(56, 20);
            this.radSnake.TabIndex = 7;
            this.radSnake.TabStop = true;
            this.radSnake.Text = "Snake";
            this.radSnake.UseVisualStyleBackColor = true;
            // 
            // bntSelect
            // 
            this.bntSelect.Location = new System.Drawing.Point(795, 268);
            this.bntSelect.Name = "bntSelect";
            this.bntSelect.Size = new System.Drawing.Size(75, 23);
            this.bntSelect.TabIndex = 8;
            this.bntSelect.Text = "&Select";
            this.bntSelect.UseVisualStyleBackColor = true;
            this.bntSelect.Click += new System.EventHandler(this.bntSelect_Click);
            // 
            // bntClose
            // 
            this.bntClose.Location = new System.Drawing.Point(796, 399);
            this.bntClose.Name = "bntClose";
            this.bntClose.Size = new System.Drawing.Size(75, 23);
            this.bntClose.TabIndex = 9;
            this.bntClose.Text = "&Close";
            this.bntClose.UseVisualStyleBackColor = true;
            this.bntClose.Click += new System.EventHandler(this.bntClose_Click);
            // 
            // frmCourseWork2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1357, 955);
            this.Controls.Add(this.bntClose);
            this.Controls.Add(this.bntSelect);
            this.Controls.Add(this.radSnake);
            this.Controls.Add(this.radBird);
            this.Controls.Add(this.radCat);
            this.Controls.Add(this.radDog);
            this.Controls.Add(this.lblPetSelect);
            this.Controls.Add(this.lblRadio);
            this.Controls.Add(this.bntChange);
            this.Controls.Add(this.lblWelcome);
            this.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmCourseWork2";
            this.Text = "Welcome Screen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button bntChange;
        private System.Windows.Forms.Label lblRadio;
        private System.Windows.Forms.Label lblPetSelect;
        private System.Windows.Forms.RadioButton radDog;
        private System.Windows.Forms.RadioButton radCat;
        private System.Windows.Forms.RadioButton radBird;
        private System.Windows.Forms.RadioButton radSnake;
        private System.Windows.Forms.Button bntSelect;
        private System.Windows.Forms.Button bntClose;
    }
}

