﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmCourseWork2 : Form
    {
        public frmCourseWork2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bntChange_Click(object sender, EventArgs e)
        {
            lblWelcome.Text = "You are going to love it";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bntClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bntSelect_Click(object sender, EventArgs e)
        {
            if (radDog.Checked == true)
            {
                lblPetSelect.Text = "You like dogs !";
            }
            else if (radCat.Checked == true)
            {
                lblPetSelect.Text = "You like Cats !";
            }
            else if (radBird.Checked == true)
            {
                lblPetSelect.Text = "You like Bitd !";
            }
            else if (radSnake.Checked == true)
            {
                lblPetSelect.Text = "Ewww.... You like snakes ";
            }

            }
    }
}
