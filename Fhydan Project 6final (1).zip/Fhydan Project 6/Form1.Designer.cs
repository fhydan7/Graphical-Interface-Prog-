﻿namespace Fhydan_Project_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAscending = new System.Windows.Forms.Button();
            this.btnDescending = new System.Windows.Forms.Button();
            this.btnShowYearsandWinning = new System.Windows.Forms.Button();
            this.btnRemoveTeamDuplicates = new System.Windows.Forms.Button();
            this.btnOneTimeChamps = new System.Windows.Forms.Button();
            this.btnCalculateCampionships = new System.Windows.Forms.Button();
            this.btnCalculateEnterYear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblWonChampionships = new System.Windows.Forms.Label();
            this.lblEnterYear = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblHowManyTeams = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAscending
            // 
            this.btnAscending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAscending.Location = new System.Drawing.Point(453, 75);
            this.btnAscending.Name = "btnAscending";
            this.btnAscending.Size = new System.Drawing.Size(129, 33);
            this.btnAscending.TabIndex = 0;
            this.btnAscending.Text = "Ascending";
            this.btnAscending.UseVisualStyleBackColor = true;
            this.btnAscending.Click += new System.EventHandler(this.btnAscending_Click);
            // 
            // btnDescending
            // 
            this.btnDescending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDescending.Location = new System.Drawing.Point(453, 138);
            this.btnDescending.Name = "btnDescending";
            this.btnDescending.Size = new System.Drawing.Size(129, 33);
            this.btnDescending.TabIndex = 1;
            this.btnDescending.Text = "Descending";
            this.btnDescending.UseVisualStyleBackColor = true;
            this.btnDescending.Click += new System.EventHandler(this.btnDescending_Click);
            // 
            // btnShowYearsandWinning
            // 
            this.btnShowYearsandWinning.AutoSize = true;
            this.btnShowYearsandWinning.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowYearsandWinning.Location = new System.Drawing.Point(453, 192);
            this.btnShowYearsandWinning.Name = "btnShowYearsandWinning";
            this.btnShowYearsandWinning.Size = new System.Drawing.Size(306, 34);
            this.btnShowYearsandWinning.TabIndex = 2;
            this.btnShowYearsandWinning.Text = "Show Years and Winning team";
            this.btnShowYearsandWinning.UseVisualStyleBackColor = true;
            this.btnShowYearsandWinning.Click += new System.EventHandler(this.btnShowYearsandWinning_Click);
            // 
            // btnRemoveTeamDuplicates
            // 
            this.btnRemoveTeamDuplicates.AutoSize = true;
            this.btnRemoveTeamDuplicates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveTeamDuplicates.Location = new System.Drawing.Point(453, 245);
            this.btnRemoveTeamDuplicates.Name = "btnRemoveTeamDuplicates";
            this.btnRemoveTeamDuplicates.Size = new System.Drawing.Size(306, 34);
            this.btnRemoveTeamDuplicates.TabIndex = 3;
            this.btnRemoveTeamDuplicates.Text = "Remove Team duplicates";
            this.btnRemoveTeamDuplicates.UseVisualStyleBackColor = true;
            this.btnRemoveTeamDuplicates.Click += new System.EventHandler(this.btnRemoveTeamDuplicates_Click);
            // 
            // btnOneTimeChamps
            // 
            this.btnOneTimeChamps.AutoSize = true;
            this.btnOneTimeChamps.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOneTimeChamps.Location = new System.Drawing.Point(453, 301);
            this.btnOneTimeChamps.Name = "btnOneTimeChamps";
            this.btnOneTimeChamps.Size = new System.Drawing.Size(161, 34);
            this.btnOneTimeChamps.TabIndex = 4;
            this.btnOneTimeChamps.Text = "One Time Champs";
            this.btnOneTimeChamps.UseVisualStyleBackColor = true;
            this.btnOneTimeChamps.Click += new System.EventHandler(this.btnOneTimeChamps_Click);
            // 
            // btnCalculateCampionships
            // 
            this.btnCalculateCampionships.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculateCampionships.Location = new System.Drawing.Point(647, 382);
            this.btnCalculateCampionships.Name = "btnCalculateCampionships";
            this.btnCalculateCampionships.Size = new System.Drawing.Size(112, 36);
            this.btnCalculateCampionships.TabIndex = 5;
            this.btnCalculateCampionships.Text = "Calculate";
            this.btnCalculateCampionships.UseVisualStyleBackColor = true;
            this.btnCalculateCampionships.Click += new System.EventHandler(this.btnCalculateCampionships_Click);
            // 
            // btnCalculateEnterYear
            // 
            this.btnCalculateEnterYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculateEnterYear.Location = new System.Drawing.Point(647, 437);
            this.btnCalculateEnterYear.Name = "btnCalculateEnterYear";
            this.btnCalculateEnterYear.Size = new System.Drawing.Size(112, 36);
            this.btnCalculateEnterYear.TabIndex = 6;
            this.btnCalculateEnterYear.Text = "Calculate";
            this.btnCalculateEnterYear.UseVisualStyleBackColor = true;
            this.btnCalculateEnterYear.Click += new System.EventHandler(this.btnCalculateEnterYear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(684, 514);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 33);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(525, 514);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 33);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblWonChampionships
            // 
            this.lblWonChampionships.AutoEllipsis = true;
            this.lblWonChampionships.AutoSize = true;
            this.lblWonChampionships.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWonChampionships.Location = new System.Drawing.Point(377, 387);
            this.lblWonChampionships.Name = "lblWonChampionships";
            this.lblWonChampionships.Size = new System.Drawing.Size(125, 16);
            this.lblWonChampionships.TabIndex = 9;
            this.lblWonChampionships.Text = "# of Championships";
            this.lblWonChampionships.Click += new System.EventHandler(this.lblWonChampionships_Click);
            // 
            // lblEnterYear
            // 
            this.lblEnterYear.AutoSize = true;
            this.lblEnterYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterYear.Location = new System.Drawing.Point(403, 448);
            this.lblEnterYear.Name = "lblEnterYear";
            this.lblEnterYear.Size = new System.Drawing.Size(77, 16);
            this.lblEnterYear.TabIndex = 10;
            this.lblEnterYear.Text = "Enter Year :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(525, 384);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(92, 22);
            this.textBox1.TabIndex = 11;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(525, 445);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(92, 22);
            this.textBox2.TabIndex = 12;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(30, 75);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(341, 472);
            this.listBox1.TabIndex = 13;
            // 
            // lblHowManyTeams
            // 
            this.lblHowManyTeams.AutoSize = true;
            this.lblHowManyTeams.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHowManyTeams.Location = new System.Drawing.Point(51, 44);
            this.lblHowManyTeams.Name = "lblHowManyTeams";
            this.lblHowManyTeams.Size = new System.Drawing.Size(164, 20);
            this.lblHowManyTeams.TabIndex = 14;
            this.lblHowManyTeams.Text = "How Many Teams ?";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 601);
            this.Controls.Add(this.lblHowManyTeams);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblEnterYear);
            this.Controls.Add(this.lblWonChampionships);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCalculateEnterYear);
            this.Controls.Add(this.btnCalculateCampionships);
            this.Controls.Add(this.btnOneTimeChamps);
            this.Controls.Add(this.btnRemoveTeamDuplicates);
            this.Controls.Add(this.btnShowYearsandWinning);
            this.Controls.Add(this.btnDescending);
            this.Controls.Add(this.btnAscending);
            this.Name = "Form1";
            this.Text = "Fhydan Project 6";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAscending;
        private System.Windows.Forms.Button btnDescending;
        private System.Windows.Forms.Button btnShowYearsandWinning;
        private System.Windows.Forms.Button btnRemoveTeamDuplicates;
        private System.Windows.Forms.Button btnOneTimeChamps;
        private System.Windows.Forms.Button btnCalculateCampionships;
        private System.Windows.Forms.Button btnCalculateEnterYear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblWonChampionships;
        private System.Windows.Forms.Label lblEnterYear;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblHowManyTeams;
    }
}

