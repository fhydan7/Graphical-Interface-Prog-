﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Fhydan_Project_6
{
    public partial class Form1 : Form
    {
        string[] teams = File.ReadAllLines("winners.txt");
        string[] Winnerbyyear = File.ReadAllLines("winnersdates.txt");
        public Form1()
        {
            InitializeComponent();
        }

        int inputNumChamps;
        int inputYear;


        private void lblWonChampionships_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void LabelChange()
        {
            lblHowManyTeams.Text = listBox1.Items.Count + " total teams.";
        }

        private void btnAscending_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var ascendQuery = from i in teams
                              orderby i ascending
                              select i;

            foreach (var n in ascendQuery)
            {
                listBox1.Items.Add(n);
            }
            LabelChange();
        }

        private void btnDescending_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var descendQuery = from i in teams
                              orderby i descending
                              select i;

            foreach (var n in descendQuery)
            {
                listBox1.Items.Add(n);
            }
            LabelChange();
        }

        private void btnShowYearsandWinning_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            var teambyyear = from year in Winnerbyyear
                             let winyear = year.Split(',')
                             let time = winyear[0]
                             let name = winyear[1]
                             orderby year ascending
                             select new { time, name };
            foreach (var n in teambyyear)
            {
                listBox1.Items.Add(n.time + " the winner was: " + n.name);

            }
            LabelChange();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRemoveTeamDuplicates_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string[] rmDuplicate = teams.Distinct().ToArray();
            var rmDuplicateQuery = from i in rmDuplicate
                              orderby i ascending
                              select i;

            
            foreach (var n in rmDuplicateQuery)
            {
                listBox1.Items.Add(n);
            }
            LabelChange();
        }

        private void btnOneTimeChamps_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            List<string> champs = File.ReadAllLines("winners.txt").ToList();
            int NumChamps = 0;
            for (int count = 0; count < champs.Count; count++)
            {
                for (int j=0; j< champs.Count; j++)
                {
                    if (champs[count].ToUpper() == champs[j].ToUpper())
                    {
                        NumChamps++;
                    }
                }
                if (NumChamps == 1)
                {
                    string oneTimeChamps = champs[count].ToString();
                    listBox1.Items.Add(oneTimeChamps);
                }
                NumChamps = 0;
            }
            LabelChange();
        }

        private void btnCalculateCampionships_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            do
            {
                try
                {
                    inputNumChamps = Convert.ToInt32(textBox1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please enter numeric value.");
                    textBox1.Text = Convert.ToString(0);
                }

                if (inputNumChamps >= 8)
                {
                    MessageBox.Show("No team has been the champion for more than 7 times.");
                    textBox1.Text = Convert.ToString(0);
                }

            } while (inputNumChamps < 0);

            List<string> champs = File.ReadAllLines("winners.txt").ToList();

            string oneTimeChamps = "";
            int NumChamps = 0;

            for (int count = 0; count < champs.Count; count++)
            {
                for (int j = 0; j < champs.Count; j++)
                {
                    if (champs[count].ToUpper() == champs[j].ToUpper())
                    {
                        NumChamps++;
                    }
                }
                if (inputNumChamps == NumChamps)
                {
                    
                    if (oneTimeChamps.ToUpper() != champs[count].ToUpper())
                    {
                        oneTimeChamps = champs[count];
                        if (!listBox1.Items.Contains(oneTimeChamps))
                        {
                            listBox1.Items.Add(oneTimeChamps);
                        }
                    }
                }
                NumChamps = 0;
            }
            LabelChange();
        }

        private void btnCalculateEnterYear_Click(object sender, EventArgs e)
        {
            do
            {
                try
                {
                    inputYear = Convert.ToInt32(textBox2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please enter numeric value.");
                    textBox2.Text = Convert.ToString(1967);
                }

                if (inputYear < 1967 || inputYear > 2018)
                {
                    MessageBox.Show("Information is only available for teams that won between 1967 and 2018, both inclusive.");
                    textBox2.Text = Convert.ToString(1967);
                }
            } while (inputYear < 0);

            listBox1.Items.Clear();
            var teambyyear = from year in Winnerbyyear
                             let winyear = year.Split(',')
                             let time = winyear[0]
                             let name = winyear[1]
                             orderby year ascending
                             select new { time, name };
            foreach (var n in teambyyear)
            {
                if (Convert.ToInt32(n.time) == inputYear)
                {
                    listBox1.Items.Add("The winner was: " + n.name);
                }
            }
            LabelChange();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            listBox1.Items.Clear();
            lblHowManyTeams.Text = "How Many teams?";
        }
    }
}
