﻿namespace Project7
{
    partial class tickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ticketsGrpbx = new System.Windows.Forms.GroupBox();
            this.ticketsLblUpperDeck = new System.Windows.Forms.Label();
            this.ticketsLblClubLevel = new System.Windows.Forms.Label();
            this.ticketsLblLowerLevel = new System.Windows.Forms.Label();
            this.ticketsLblQuantity = new System.Windows.Forms.Label();
            this.ticketsCmbxUpperDeck = new System.Windows.Forms.ComboBox();
            this.ticketsCmbxClubLevel = new System.Windows.Forms.ComboBox();
            this.ticketsCmbxLowerLevel = new System.Windows.Forms.ComboBox();
            this.ticketsBtnBuy = new System.Windows.Forms.Button();
            this.ticketsGrpbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // ticketsGrpbx
            // 
            this.ticketsGrpbx.Controls.Add(this.ticketsLblUpperDeck);
            this.ticketsGrpbx.Controls.Add(this.ticketsLblClubLevel);
            this.ticketsGrpbx.Controls.Add(this.ticketsLblLowerLevel);
            this.ticketsGrpbx.Controls.Add(this.ticketsLblQuantity);
            this.ticketsGrpbx.Controls.Add(this.ticketsCmbxUpperDeck);
            this.ticketsGrpbx.Controls.Add(this.ticketsCmbxClubLevel);
            this.ticketsGrpbx.Controls.Add(this.ticketsCmbxLowerLevel);
            this.ticketsGrpbx.Controls.Add(this.ticketsBtnBuy);
            this.ticketsGrpbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsGrpbx.Location = new System.Drawing.Point(69, 43);
            this.ticketsGrpbx.Name = "ticketsGrpbx";
            this.ticketsGrpbx.Size = new System.Drawing.Size(647, 338);
            this.ticketsGrpbx.TabIndex = 0;
            this.ticketsGrpbx.TabStop = false;
            this.ticketsGrpbx.Text = "Tickets";
            // 
            // ticketsLblUpperDeck
            // 
            this.ticketsLblUpperDeck.AutoSize = true;
            this.ticketsLblUpperDeck.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsLblUpperDeck.Location = new System.Drawing.Point(66, 191);
            this.ticketsLblUpperDeck.Name = "ticketsLblUpperDeck";
            this.ticketsLblUpperDeck.Size = new System.Drawing.Size(247, 31);
            this.ticketsLblUpperDeck.TabIndex = 7;
            this.ticketsLblUpperDeck.Text = "Upper Deck: $50.00";
            // 
            // ticketsLblClubLevel
            // 
            this.ticketsLblClubLevel.AutoSize = true;
            this.ticketsLblClubLevel.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsLblClubLevel.Location = new System.Drawing.Point(66, 120);
            this.ticketsLblClubLevel.Name = "ticketsLblClubLevel";
            this.ticketsLblClubLevel.Size = new System.Drawing.Size(243, 31);
            this.ticketsLblClubLevel.TabIndex = 6;
            this.ticketsLblClubLevel.Text = "Club Level : $75.00";
            // 
            // ticketsLblLowerLevel
            // 
            this.ticketsLblLowerLevel.AutoSize = true;
            this.ticketsLblLowerLevel.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsLblLowerLevel.Location = new System.Drawing.Point(66, 59);
            this.ticketsLblLowerLevel.Name = "ticketsLblLowerLevel";
            this.ticketsLblLowerLevel.Size = new System.Drawing.Size(267, 31);
            this.ticketsLblLowerLevel.TabIndex = 5;
            this.ticketsLblLowerLevel.Text = "Lower Level: $125.00";
            // 
            // ticketsLblQuantity
            // 
            this.ticketsLblQuantity.AutoSize = true;
            this.ticketsLblQuantity.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsLblQuantity.Location = new System.Drawing.Point(391, 22);
            this.ticketsLblQuantity.Name = "ticketsLblQuantity";
            this.ticketsLblQuantity.Size = new System.Drawing.Size(127, 31);
            this.ticketsLblQuantity.TabIndex = 4;
            this.ticketsLblQuantity.Text = "Quantity:";
            // 
            // ticketsCmbxUpperDeck
            // 
            this.ticketsCmbxUpperDeck.FormattingEnabled = true;
            this.ticketsCmbxUpperDeck.Location = new System.Drawing.Point(397, 191);
            this.ticketsCmbxUpperDeck.Name = "ticketsCmbxUpperDeck";
            this.ticketsCmbxUpperDeck.Size = new System.Drawing.Size(121, 27);
            this.ticketsCmbxUpperDeck.TabIndex = 3;
            this.ticketsCmbxUpperDeck.Text = "0";
            this.ticketsCmbxUpperDeck.SelectedIndexChanged += new System.EventHandler(this.ticketsCmbxUpperDeck_SelectedIndexChanged);
            // 
            // ticketsCmbxClubLevel
            // 
            this.ticketsCmbxClubLevel.FormattingEnabled = true;
            this.ticketsCmbxClubLevel.Location = new System.Drawing.Point(397, 130);
            this.ticketsCmbxClubLevel.Name = "ticketsCmbxClubLevel";
            this.ticketsCmbxClubLevel.Size = new System.Drawing.Size(121, 27);
            this.ticketsCmbxClubLevel.TabIndex = 2;
            this.ticketsCmbxClubLevel.Text = "0";
            this.ticketsCmbxClubLevel.SelectedIndexChanged += new System.EventHandler(this.ticketsCmbxClubLevel_SelectedIndexChanged);
            // 
            // ticketsCmbxLowerLevel
            // 
            this.ticketsCmbxLowerLevel.FormattingEnabled = true;
            this.ticketsCmbxLowerLevel.Location = new System.Drawing.Point(397, 70);
            this.ticketsCmbxLowerLevel.Name = "ticketsCmbxLowerLevel";
            this.ticketsCmbxLowerLevel.Size = new System.Drawing.Size(121, 27);
            this.ticketsCmbxLowerLevel.TabIndex = 1;
            this.ticketsCmbxLowerLevel.Text = "0";
            this.ticketsCmbxLowerLevel.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // ticketsBtnBuy
            // 
            this.ticketsBtnBuy.BackColor = System.Drawing.Color.DodgerBlue;
            this.ticketsBtnBuy.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsBtnBuy.ForeColor = System.Drawing.Color.White;
            this.ticketsBtnBuy.Location = new System.Drawing.Point(258, 255);
            this.ticketsBtnBuy.Name = "ticketsBtnBuy";
            this.ticketsBtnBuy.Size = new System.Drawing.Size(115, 49);
            this.ticketsBtnBuy.TabIndex = 0;
            this.ticketsBtnBuy.Text = "Buy";
            this.ticketsBtnBuy.UseVisualStyleBackColor = false;
            this.ticketsBtnBuy.Click += new System.EventHandler(this.button1_Click);
            // 
            // tickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ticketsGrpbx);
            this.Name = "tickets";
            this.Text = "Tickets";
            this.ticketsGrpbx.ResumeLayout(false);
            this.ticketsGrpbx.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ticketsGrpbx;
        private System.Windows.Forms.Label ticketsLblUpperDeck;
        private System.Windows.Forms.Label ticketsLblClubLevel;
        private System.Windows.Forms.Label ticketsLblLowerLevel;
        private System.Windows.Forms.Label ticketsLblQuantity;
        private System.Windows.Forms.ComboBox ticketsCmbxUpperDeck;
        private System.Windows.Forms.ComboBox ticketsCmbxClubLevel;
        private System.Windows.Forms.ComboBox ticketsCmbxLowerLevel;
        private System.Windows.Forms.Button ticketsBtnBuy;
    }
}