﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project7
{
    public partial class Purchaseconfirm : Form
    {
        public Purchaseconfirm()
        {
            InitializeComponent();
            CalculateTotalCost();
            lblTotalCost.Text = "Total Cost: " + Customer.TotalCosts.ToString("c2");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void CalculateTotalCost()
        {
            double LLCost = Customer.NumberofTicketsL1 * 125;
            double CLCost = Customer.NumberofTicketsL2 * 75;
            double UDCost = Customer.NumberofTicketsL3 * 50;

            Customer.TotalCosts = LLCost + CLCost + UDCost;
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // if condition to check if the CC number is greater than 16
            //try catch to catch the number format exception for the credit card number 
            // sending CCNumber to the customer class.
            if (txtCCNum.Text.Length > 16)
            {
                MessageBox.Show("Invalid input. Please only enter (16) integers.", "Error - Credit Card Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCCNum.SelectAll();
            }

            try
            {
                Customer.CreditCardNumber = Convert.ToDouble(txtCCNum.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid input. Please only enter integers.", "Error - Credit Card Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCCNum.SelectAll();
            }

            //Sending Credit Card Name to the Customer class
            Customer.CreditCardName = txtCCName.Text;

            // if condition to check if the CSV is greater than 3
            //try catch to catch the number format exception for the CSV 
            // sending CSV to the customer class.
            if (txtCSV.Text.Length > 3)
            {
                MessageBox.Show("Invalid input. Please only enter (3) integers.", "Error - CSV", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCSV.SelectAll();
            }

            try
            {
                Customer.CSV = Convert.ToInt32(txtCSV.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid input. Please only enter integers.", "Error - CSV", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCSV.SelectAll();
            }

            // Checking if any of the text boxes are empty
            if (txtCCName.Text == null || txtCCNum == null || txtCSV.Text == null)
            {
                MessageBox.Show("Please fill the form completely.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //get Random number
            Random r = new Random();
            int randNum = r.Next(1000, 9999);

            //Gets users information and puts into an array.  Gets confirmation. Display user information from customer class.

            string[] CustomerArray = new string[11];

            CustomerArray[0] = Customer.CustomerName;
            CustomerArray[1] = Customer.Email;
            CustomerArray[2] = Customer.Age.ToString();
            CustomerArray[3] = txtCCNum.Text;
            CustomerArray[4] = txtCCName.Text;
            CustomerArray[5] = txtCSV.Text;
            CustomerArray[6] = Customer.TotalCosts.ToString();
            CustomerArray[7] = Customer.NumberofTicketsL1.ToString();
            CustomerArray[8] = Customer.NumberofTicketsL2.ToString();
            CustomerArray[9] = Customer.NumberofTicketsL3.ToString();
            CustomerArray[10] = randNum.ToString();

            DialogResult result = (MessageBox.Show("Can't wait to see you! " + Customer.CustomerName.ToUpper() 
                + "\nSummary:"  + "Please confirm you purchase of:  " + Customer.TotalCosts.ToString("c2")
                + "\nContact e-mail: " + Customer.Email 
                + "\n\n" + "Please click YES below to confirm your order", 
                "Confirmation", MessageBoxButtons.YesNoCancel));

            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Thank you for your order!" + "\n" + "Your confirmation number is: " + randNum, "Congrats! Order Confirmed.",MessageBoxButtons.OK);
                string CustomerLoad = string.Join(",", CustomerArray);

                File.AppendAllText("CustomerInfo.txt", CustomerLoad + "\r\n");

                this.Close();
                Environment.Exit(1);

            }
        }

        private void lblTotalCost_Click(object sender, EventArgs e)
        {
 
        }
    }
}
