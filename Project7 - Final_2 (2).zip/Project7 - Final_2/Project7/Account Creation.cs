﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class AccountCreation : Form
    {
        public AccountCreation()
        {
            InitializeComponent();
        }

        private void AccountCreation_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool validauth = true;

            // Regex for email validation.
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (Convert.ToInt32(txtAge.Text) <= 16)
            {
                MessageBox.Show("Sorry. User should be above 16 to be able to create an account.", "Inappropraite Age", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (txtEmailCreation.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtEmailCreation.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmailCreation.SelectAll();
                }

                if (rEMail.IsMatch(txtEmailCreation.Text) && Convert.ToInt32(txtAge.Text) > 16)
                {
                    if (File.Exists("usersaccounts.txt"))
                    {
                        string[] existingaccounts = File.ReadAllLines("usersaccounts.txt");
                        string email = txtEmailCreation.Text;
                        var emailQuery = from name in existingaccounts
                                         let loademail = name.Split(',')
                                         let user = loademail[loademail.Length - 4]
                                         let useremail = loademail[loademail.Length - 3]
                                         let userage = loademail[loademail.Length - 2]
                                         let userpwd = loademail[loademail.Length - 1]
                                         select new { user, useremail, userage, userpwd };

                        foreach (var name in emailQuery)
                        {
                            if (name.useremail.ToLower() == email.ToLower())
                            {
                                MessageBox.Show("User with email " + txtEmailCreation.Text + " already exists. Please " +
                                    "use a different email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                validauth = false;
                                break;
                            }
                            txtEmailCreation.SelectAll();
                        }
                    }
                    else
                    {
                        //sending data to customer class
                        Customer.CustomerName = txtName.Text;
                        Customer.Email = txtEmailCreation.Text;
                        Customer.Age = int.Parse(txtAge.Text);

                        //writing customerinfo to textfile
                        string[] usersaccount = new string[4];
                        usersaccount[0] = Customer.CustomerName;
                        usersaccount[1] = Customer.Email;
                        usersaccount[2] = Customer.Age.ToString();
                        usersaccount[3] = txtPasswordCreation.Text;

                        string accountload = string.Join(",", usersaccount);

                        File.AppendAllText("usersaccounts.txt", accountload + "\r\n");

                        // Moving to the next form
                        this.Hide();
                        tickets tickets = new tickets();
                        tickets.ShowDialog();
                    }


                    if (validauth == true)
                    {
                        //sending data to customer class
                        Customer.CustomerName = txtName.Text;
                        Customer.Email = txtEmailCreation.Text;
                        Customer.Age = int.Parse(txtAge.Text);

                        //writing customerinfo to textfile
                        string[] usersaccount = new string[4];
                        usersaccount[0] = Customer.CustomerName;
                        usersaccount[1] = Customer.Email;
                        usersaccount[2] = Customer.Age.ToString();
                        usersaccount[3] = txtPasswordCreation.Text;

                        string accountload = string.Join(",", usersaccount);

                        File.AppendAllText("usersaccounts.txt", accountload + "\r\n");

                        this.Hide();
                        tickets tickets = new tickets();
                        tickets.ShowDialog();
                    }

                }
            }
        }
    }
}

