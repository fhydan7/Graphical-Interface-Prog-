﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project7
{
    public partial class tickets : Form
    {
        public int LLseats = 200;
        public int CLseats = 75;
        public int UDseats = 200;

        public tickets()
        {
            InitializeComponent();
            // Display the remiaining seats for the Lower Level Seats
            if (File.Exists("CustomerInfo.txt"))
            {
                string[] CustomerInfo = File.ReadAllLines("CustomerInfo.txt");
                var Info = from Seats in CustomerInfo
                           let loadseats = Seats.Split(',')
                           let Lseats = Convert.ToInt32(loadseats[7])
                           select new { Lseats };

                foreach (var Seats in Info)
                {
                    LLseats -= Seats.Lseats;
                }

                if (LLseats == 0)
                {
                    ticketsLblLowerLevel.Text = "Sold Out.";
                    ticketsCmbxLowerLevel.Visible = false;
                }
                else
                {
                    for (int i = 1; i <= LLseats; i++)
                    {
                        string[] numbers = { i.ToString() };
                        ticketsCmbxLowerLevel.Items.AddRange(numbers);
                    }
                }

            }
            else
            {
                for (int i = 1; i <= LLseats; i++)
                {
                    string[] numbers = { i.ToString() };
                    ticketsCmbxLowerLevel.Items.AddRange(numbers);
                }
            }

            // Display the remiaining seats for the Club Level Seats
            if (File.Exists("CustomerInfo.txt"))
            {
                string[] CustomerInfo = File.ReadAllLines("CustomerInfo.txt");
                var Info = from Seats in CustomerInfo
                           let loadseats = Seats.Split(',')
                           let Cseats = Convert.ToInt32(loadseats[8])
                           select new { Cseats };

                foreach (var Seats in Info)
                {
                    CLseats -= Seats.Cseats;
                }

                if (CLseats == 0)
                {
                    ticketsLblClubLevel.Text = "Sold Out.";
                    ticketsCmbxClubLevel.Visible = false;
                }
                else
                {
                    for (int i = 1; i <= CLseats; i++)
                    {
                        string[] numbers = { i.ToString() };
                        ticketsCmbxClubLevel.Items.AddRange(numbers);
                    }
                }
            }
            else
            {
                for (int i = 1; i <= CLseats; i++)
                {
                    string[] numbers = { i.ToString() };
                    ticketsCmbxClubLevel.Items.AddRange(numbers);
                }
            }

            // Display the remiaining seats for the Upper Deck Seats
            if (File.Exists("CustomerInfo.txt"))
            {
                string[] CustomerInfo = File.ReadAllLines("CustomerInfo.txt");
                var Info = from Seats in CustomerInfo
                           let loadseats = Seats.Split(',')
                           let UDseats = Convert.ToInt32(loadseats[9])
                           select new { UDseats };

                foreach (var Seats in Info)
                {
                    UDseats -= Seats.UDseats;
                }
                if (UDseats == 0)
                {
                    ticketsLblUpperDeck.Text = "Sold Out.";
                    ticketsCmbxUpperDeck.Visible = false;
                }
                else
                {
                    for (int i = 1; i <= UDseats; i++)
                    {
                        string[] numbers = { i.ToString() };
                        ticketsCmbxUpperDeck.Items.AddRange(numbers);
                    }
                }
            }
            else
            {
                for (int i = 1; i <= UDseats; i++)
                {
                    string[] numbers = { i.ToString() };
                    ticketsCmbxUpperDeck.Items.AddRange(numbers);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer.NumberofTicketsL1 = Convert.ToInt32(ticketsCmbxLowerLevel.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Purchaseconfirm purchaseconfirm = new Purchaseconfirm();
            purchaseconfirm.ShowDialog();
        }

        private void ticketsCmbxClubLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer.NumberofTicketsL2 = Convert.ToInt32(ticketsCmbxClubLevel.Text);
        }

        private void ticketsCmbxUpperDeck_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer.NumberofTicketsL3 = Convert.ToInt32(ticketsCmbxUpperDeck.Text);
        }
    }
}
