﻿namespace Project7
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConfirmayionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LowerLevelSeats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClubLevelSeats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpperDeckSeats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblAdminUDSeats = new System.Windows.Forms.Label();
            this.lblAdminCLSeats = new System.Windows.Forms.Label();
            this.lblAdminLLSeats = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAdminFind = new System.Windows.Forms.Button();
            this.txtAdminConfirmation = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblAdminTotalSalesDollar = new System.Windows.Forms.Label();
            this.btnAdminClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Customer,
            this.email,
            this.TotalCost,
            this.ConfirmayionNumber,
            this.LowerLevelSeats,
            this.ClubLevelSeats,
            this.UpperDeckSeats});
            this.dataGridView1.Location = new System.Drawing.Point(48, 210);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(803, 307);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Customer
            // 
            this.Customer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Customer.HeaderText = "Customer";
            this.Customer.Name = "Customer";
            // 
            // email
            // 
            this.email.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.email.HeaderText = "Email";
            this.email.Name = "email";
            // 
            // TotalCost
            // 
            this.TotalCost.HeaderText = "Total Cost";
            this.TotalCost.Name = "TotalCost";
            // 
            // ConfirmayionNumber
            // 
            this.ConfirmayionNumber.HeaderText = "Confirmation Number";
            this.ConfirmayionNumber.Name = "ConfirmayionNumber";
            // 
            // LowerLevelSeats
            // 
            this.LowerLevelSeats.HeaderText = "Lower Level Seats";
            this.LowerLevelSeats.Name = "LowerLevelSeats";
            // 
            // ClubLevelSeats
            // 
            this.ClubLevelSeats.HeaderText = "Club Level Seats";
            this.ClubLevelSeats.Name = "ClubLevelSeats";
            // 
            // UpperDeckSeats
            // 
            this.UpperDeckSeats.HeaderText = "Upper Deck Seats";
            this.UpperDeckSeats.Name = "UpperDeckSeats";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblAdminUDSeats);
            this.groupBox1.Controls.Add(this.lblAdminCLSeats);
            this.groupBox1.Controls.Add(this.lblAdminLLSeats);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(48, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(379, 135);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seats Remaining";
            // 
            // lblAdminUDSeats
            // 
            this.lblAdminUDSeats.AutoSize = true;
            this.lblAdminUDSeats.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminUDSeats.Location = new System.Drawing.Point(293, 100);
            this.lblAdminUDSeats.Name = "lblAdminUDSeats";
            this.lblAdminUDSeats.Size = new System.Drawing.Size(33, 19);
            this.lblAdminUDSeats.TabIndex = 5;
            this.lblAdminUDSeats.Text = "200";
            // 
            // lblAdminCLSeats
            // 
            this.lblAdminCLSeats.AutoSize = true;
            this.lblAdminCLSeats.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminCLSeats.Location = new System.Drawing.Point(190, 100);
            this.lblAdminCLSeats.Name = "lblAdminCLSeats";
            this.lblAdminCLSeats.Size = new System.Drawing.Size(25, 19);
            this.lblAdminCLSeats.TabIndex = 4;
            this.lblAdminCLSeats.Text = "74";
            // 
            // lblAdminLLSeats
            // 
            this.lblAdminLLSeats.AutoSize = true;
            this.lblAdminLLSeats.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminLLSeats.Location = new System.Drawing.Point(46, 100);
            this.lblAdminLLSeats.Name = "lblAdminLLSeats";
            this.lblAdminLLSeats.Size = new System.Drawing.Size(33, 19);
            this.lblAdminLLSeats.TabIndex = 3;
            this.lblAdminLLSeats.Text = "189";
            this.lblAdminLLSeats.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(260, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Upper Deck:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(145, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Club level:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Lower Level: ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAdminFind);
            this.groupBox2.Controls.Add(this.txtAdminConfirmation);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(433, 69);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(358, 135);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Guest Lookup";
            // 
            // btnAdminFind
            // 
            this.btnAdminFind.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAdminFind.ForeColor = System.Drawing.Color.White;
            this.btnAdminFind.Location = new System.Drawing.Point(108, 95);
            this.btnAdminFind.Name = "btnAdminFind";
            this.btnAdminFind.Size = new System.Drawing.Size(102, 29);
            this.btnAdminFind.TabIndex = 6;
            this.btnAdminFind.Text = "Find";
            this.btnAdminFind.UseVisualStyleBackColor = false;
            this.btnAdminFind.Click += new System.EventHandler(this.btnAdminFind_Click);
            // 
            // txtAdminConfirmation
            // 
            this.txtAdminConfirmation.Location = new System.Drawing.Point(171, 53);
            this.txtAdminConfirmation.Multiline = true;
            this.txtAdminConfirmation.Name = "txtAdminConfirmation";
            this.txtAdminConfirmation.Size = new System.Drawing.Size(161, 31);
            this.txtAdminConfirmation.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(159, 19);
            this.label7.TabIndex = 4;
            this.label7.Text = "Confirmation Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(192, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 22);
            this.label8.TabIndex = 3;
            this.label8.Text = "Total sales";
            // 
            // lblAdminTotalSalesDollar
            // 
            this.lblAdminTotalSalesDollar.AutoSize = true;
            this.lblAdminTotalSalesDollar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminTotalSalesDollar.ForeColor = System.Drawing.Color.Red;
            this.lblAdminTotalSalesDollar.Location = new System.Drawing.Point(323, 26);
            this.lblAdminTotalSalesDollar.Name = "lblAdminTotalSalesDollar";
            this.lblAdminTotalSalesDollar.Size = new System.Drawing.Size(90, 22);
            this.lblAdminTotalSalesDollar.TabIndex = 4;
            this.lblAdminTotalSalesDollar.Text = "$1,450.00";
            // 
            // btnAdminClose
            // 
            this.btnAdminClose.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAdminClose.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdminClose.Location = new System.Drawing.Point(604, 535);
            this.btnAdminClose.Name = "btnAdminClose";
            this.btnAdminClose.Size = new System.Drawing.Size(161, 43);
            this.btnAdminClose.TabIndex = 5;
            this.btnAdminClose.Text = "Close";
            this.btnAdminClose.UseVisualStyleBackColor = false;
            this.btnAdminClose.Click += new System.EventHandler(this.btnAdminClose_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 590);
            this.Controls.Add(this.btnAdminClose);
            this.Controls.Add(this.lblAdminTotalSalesDollar);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Admin";
            this.Text = "Admin";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblAdminLLSeats;
        private System.Windows.Forms.Label lblAdminUDSeats;
        private System.Windows.Forms.Label lblAdminCLSeats;
        private System.Windows.Forms.TextBox txtAdminConfirmation;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAdminFind;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblAdminTotalSalesDollar;
        private System.Windows.Forms.Button btnAdminClose;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConfirmayionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn LowerLevelSeats;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClubLevelSeats;
        private System.Windows.Forms.DataGridViewTextBoxColumn UpperDeckSeats;
    }
}