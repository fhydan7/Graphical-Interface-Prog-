﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((txtAdminUsername.Text.ToLower().Trim() == "admin".ToString().ToLower().Trim()) &&
                    (txtAdminPassword.Text.Trim() == "BACS287".ToString().Trim()))
            {
                this.Hide();
                Admin admin = new Admin();
                admin.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid credentials. Please try again.", "Error!", MessageBoxButtons.OK);
            }
            txtAdminUsername.Focus();
        }

        private void txtAdminPassword_TextChanged(object sender, EventArgs e)
        {
            txtAdminPassword.PasswordChar = '*';
        }
    }
}
