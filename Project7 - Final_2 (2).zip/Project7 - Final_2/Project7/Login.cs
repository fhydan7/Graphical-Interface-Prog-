﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Project7
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool validauth = false;
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (txtEmail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtEmail.Text))

                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.SelectAll();
                }
            }

            if (rEMail.IsMatch(txtEmail.Text))
            {
                // Use a query to bring existing accounts from data file created in Account
                // creation form.use a loop to search through accounts and use an If statement
                // to match e - mail and password.
                if (File.Exists("usersaccounts.txt"))
                {
                    string[] existingaccounts = File.ReadAllLines("usersaccounts.txt");
                    string email = txtEmail.Text;
                    string password = txtPassword.Text;
                    var emailQuery = from name in existingaccounts
                                     let loademail = name.Split(',')
                                     let user = loademail[loademail.Length - 4]
                                     let useremail = loademail[loademail.Length - 3]
                                     let userage = loademail[loademail.Length - 2]
                                     let userpwd = loademail[loademail.Length - 1]
                                     select new { user, useremail, userage, userpwd };

                    foreach (var name in emailQuery)
                    {
                        if (name.useremail.ToLower() == email.ToLower() && name.userpwd == password)
                        {
                            Customer.Email = email.ToLower();
                            Customer.CustomerName = name.user;
                            validauth = true;
                            this.Hide();
                            tickets tickets = new tickets();
                            tickets.ShowDialog();
                        }
                    }
                    if (validauth == false)
                    {
                        MessageBox.Show("Invalid email or password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    txtEmail.SelectAll();
                }
                else
                {
                    MessageBox.Show("Email not found. Please create an account.", "Error.", MessageBoxButtons.OK);
                }
            }
                
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccountCreation accountCreation = new AccountCreation();
            accountCreation.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            String email = txtEmail.Text.ToString();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

