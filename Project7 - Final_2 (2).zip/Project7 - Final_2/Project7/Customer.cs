﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Project7
{
    public class Customer 

    {
        public static string CustomerName {  get; set; }
        public static string Email {  get; set; }
        public static string Password {  get; set; }
        public static string CreditCardName {  get; set; }
        public static int Age {  get; set; }
        public static double CreditCardNumber {  get; set; }
        public static int CSV {  get; set; }
        public static int NumberofTicketsL1 {  get; set; }
        public static int NumberofTicketsL2 {  get; set; }
        public static int NumberofTicketsL3 {  get; set; }
        public static int ConfirmationNumber {  get; set; }
        public static double TotalCosts {  get; set; }


        public Customer() { }

        public Customer(string name, string email, string password, int age)
        {
            CustomerName = name;
            Email = email;
            Password = password;
            Age = Age;
        }

        public Customer(string name, string email, string password, string creditName,
            int age, int creditNumber, int csv, int Level1, int Level2, int Level3, double cost)
        {
            CustomerName = name;
            Email = email;
            Password = password;
            CreditCardName = creditName;
            Age = age;
            CreditCardNumber = creditNumber;
            CSV = csv;
        }
                     
    }


    

}
