﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project7
{
    public partial class Admin : Form
    {
        public Admin()
        {

            InitializeComponent();
            double TotalSales = 0;
            double llTotalSeats = 0;
            double clTotalSeats = 0;
            double udTotalSeats = 0;

            //Query of customers array that contains the file data.
            string[] CustomerInfo = File.ReadAllLines("CustomerInfo.txt");
            var datagridQuery = from name in CustomerInfo
                                let getdata = name.Split(',')
                                let getname = getdata[0]
                                let useremail = getdata[1]
                                let gettotalcost = getdata[6]
                                let getConfirm = getdata[10]
                                let ll = getdata[7]
                                let cl = getdata[8]
                                let ud = getdata[9]
                                let sales = getdata[6]
                                select new { useremail, getname, gettotalcost, getConfirm, ll, cl, ud, sales };
            // create a loop to add daat into data grid.  Also, use loop to compute total seats and total sales.
            foreach (var name in datagridQuery)
            {
                //load data into data grid
                dataGridView1.Rows.Add(name.getname, name.useremail, name.gettotalcost, name.getConfirm, name.ll,
                    name.cl, name.ud);

                //computer total seats purchased
                llTotalSeats += double.Parse(name.ll);
                clTotalSeats += double.Parse(name.cl);
                udTotalSeats += double.Parse(name.ud);
                TotalSales += double.Parse(name.sales);
            }

            //display total seats remaining and total sales.
            lblAdminLLSeats.Text = (200 - llTotalSeats).ToString();
            lblAdminCLSeats.Text = (75 - clTotalSeats).ToString();
            lblAdminUDSeats.Text = (200 - udTotalSeats).ToString();
            lblAdminTotalSalesDollar.Text = TotalSales.ToString("c2");
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAdminClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //search button 
        private void btnAdminFind_Click(object sender, EventArgs e)
        {
            string confirmNum = txtAdminConfirmation.Text;
            if (File.Exists("CustomerInfo.txt"))
            {
                string[] CustomerInfo = File.ReadAllLines("CustomerInfo.txt");
                var searchNameQuery = from name in CustomerInfo
                                      let seatTotal = name.Split(',')
                                      let searchName = seatTotal[0].ToUpper()
                                      let amtCharged = seatTotal[6]
                                      let getConfirm = seatTotal[10]
                                      let ll = seatTotal[7]
                                      let cl = seatTotal[8]
                                      let ud = seatTotal[9]

                                      let confirm = seatTotal[10]
                                      select new { searchName, amtCharged, ll, cl, ud, confirm };

                foreach (var result in searchNameQuery)
                {
                    if (confirmNum == result.confirm)
                    {
                        MessageBox.Show("Found Confirmation number: " + result.confirm + "\n" + "Name:  " + result.searchName + "\n" + "Total Charge: $" + result.amtCharged + "\n", "Confirmation found", MessageBoxButtons.OK);

                    }

                }
                //highlights row.
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                try
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.Cells[3].Value.ToString().Equals(confirmNum))
                        {
                            row.Selected = true;
                            break;
                        }


                    }
                }
                catch
                {
                    MessageBox.Show("Confirmation number does not exist!", "Error");
                }
            }
            else
            {
                MessageBox.Show("No Customer Records Found.", "Error", MessageBoxButtons.OK);
            }
        }
    }
}
